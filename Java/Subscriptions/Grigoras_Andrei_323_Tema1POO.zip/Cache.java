public interface Cache {
    public static void add(){};
    public static void remove(){};
    public static void getIndex(String subscriptionName){};
}
