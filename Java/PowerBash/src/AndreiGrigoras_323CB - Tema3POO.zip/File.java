//Basic file class
class File extends Node {

    File(String dataName, Node dataFather) {
        super(dataName, dataFather, null);
    }
}
