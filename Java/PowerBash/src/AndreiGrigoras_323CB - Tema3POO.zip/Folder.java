import java.util.ArrayList;

//Folder class
class Folder extends Node {

    Folder(String foldername, Node dataFather, ArrayList<Node> folderContent) {
        super(foldername, dataFather, folderContent);
    }
}
