#include "Collider.h"

#include <iostream>
using namespace std;

Collider::Collider(int type, vec3 position, float radius, float elapsed)
{
	this->type = type;
	this->position = position;
	this->radius = radius;
	this->elapsed_time = elapsed;
}

bool Collider::CheckColision(Collider other)
{
	return distance(this->position, other.position) <= (this->radius + other.radius) / 2;
}
