#include "Avioncumotor.h"

#include <vector>
#include <string>
#include <iostream>

#include <Core/Engine.h>

using namespace std;
using namespace glm;

constexpr auto plane_scene_position = vec3(0, 1, 0);

Avioncumotor::Avioncumotor()
{
}

Avioncumotor::~Avioncumotor()
{
}

void Avioncumotor::Init()
{
	camera = new Tema::Camera();
	camera->Set(vec3(1, 2, 5), vec3(1, 1, 0), vec3(0, 1, 0));

	{
		Mesh* mesh = new Mesh("box");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "box.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("sphere");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "sphere.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("obstacle");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Props", "oildrum.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("fuel");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "teapot.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("sea");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Props", "sea.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	// Sea Shader
	{
		Shader *shader = new Shader("Wave");
		shader->AddShader(RESOURCE_PATH::SHADERS + "Wave.VS.glsl", GL_VERTEX_SHADER);
		shader->AddShader(RESOURCE_PATH::SHADERS + "Wave.FS.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}

	game_over = false;

	projectionMatrix = perspective(RADIANS(60), window->props.aspectRatio, 0.01f, 200.0f);
}

void Avioncumotor::FrameStart()
{
	glClearColor(1.0f, 0.8f, 0.6f, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void Avioncumotor::Update(float deltaTimeSeconds)
{
	static int lives = 3;
	static float fuel = 1;
	static float speed = 3;
	static Collider plane_collider(2, plane_scene_position, 1, 0);

	if (!game_over) fuel = clamp(fuel - deltaTimeSeconds / 10, 0.f, 1.f);

	// Obstacole si combustibil
	{
		static float timeout = rand() % 100 / 50.f;;
		timeout = clamp(timeout - deltaTimeSeconds, 0.f, 2.f);

		if (timeout == 0)
		{
			int type = rand() % 2;
			float pos_oy = plane_scene_position.y + rand() % 100 / 50.f;
			float initial_time = fmod(rand() % 100, M_PI);

			switch (type)
			{
			case 0:
				colliders.push_back(Collider(type, vec3(10, pos_oy, 0), 0.5f, initial_time));
				break;
			case 1:
				int fuel_amount = 3 + rand() % 4;
				for (int i = 0; i <= fuel_amount; i++) {
					double arch = sin((M_PI / fuel_amount) * i);
					colliders.push_back(Collider(type, vec3(10 + i * 0.4, pos_oy - 0.1 + arch * 0.1, 0), 0.4f, initial_time));
				}
				break;
			}

			timeout = 0.5 + rand() % 100 / 50.f;
		}

		for (Collider &c : colliders)
		{
			mat4 modelMatrix = mat4(1);
			c.position.x -= deltaTimeSeconds * speed;
			c.elapsed_time += deltaTimeSeconds * speed;
			switch (c.type)
			{
			case 0:
				modelMatrix = translate(modelMatrix, c.position);
				modelMatrix = rotate(modelMatrix, c.elapsed_time, vec3(1, 0, 1));
				modelMatrix = translate(modelMatrix, -vec3(0.05, 0.25, 0));
				modelMatrix = scale(modelMatrix, vec3(0.5, 0.5, 0.5));
				RenderMesh(meshes["obstacle"], shaders["Simple"], modelMatrix);
				break;
			case 1:
				modelMatrix = translate(modelMatrix, c.position);
				modelMatrix = rotate(modelMatrix, c.elapsed_time, vec3(0, 1, 0));
				modelMatrix = scale(modelMatrix, vec3(0.3, 0.3, 0.3));
				RenderMesh(meshes["fuel"], shaders["Color"], modelMatrix, vec3(0, 1, 0.8));
				break;
			}
		}

		colliders.erase(std::remove_if(colliders.begin(), colliders.end(),
						[](const Collider& c) { return c.position.x < -10;}), colliders.end());
	}

	// Coliziuni
	if (!game_over)
	{
		auto it = colliders.begin();
		while(it != colliders.end())
		{
			if (plane_collider.CheckColision(*it))
			{
				switch (it->type)
				{
				case 0:
					lives--;
					break;
				case 1:
					fuel = clamp(fuel + 0.1f, 0.f, 1.f);
					break;
				}
				it = colliders.erase(it);
			}
			else
				++it;
		}
	}

	if (fuel == 0 || lives <= 0)
		game_over = true;

	// Avion
	{
		static float plane_position = plane_scene_position.y;
		static float plane_rotation = 0;
		static vec3 rotation_axis = vec3(0, 0, 1);

		if (!game_over)
		{
			float move = lerp(plane_position, plane_scene_position.y + pos_mouseY, 0.5);
			plane_rotation = -(plane_position - move) * 5;
			plane_position = move;
		}
		else 
		{
			rotation_axis = vec3(1, 1, 0);
			plane_position -= deltaTimeSeconds;
			plane_rotation += deltaTimeSeconds * 5;
		}

		plane_collider.position = vec3(-0.3, plane_position, 0);

		{
			mat4 modelMatrix = mat4(1);
			modelMatrix = translate(modelMatrix, vec3(0, plane_position, 0));
			modelMatrix = rotate(modelMatrix, plane_rotation, rotation_axis);
			modelMatrix = translate(modelMatrix, vec3(-0.4, 0, 0));
			modelMatrix = scale(modelMatrix, vec3(0.8, 0.5, 0.5));
			RenderMesh(meshes["box"], shaders["Color"], modelMatrix, vec3(1, 1, 1));
		}

		{
			mat4 modelMatrix = mat4(1);
			modelMatrix = translate(modelMatrix, vec3(0, plane_position, 0));
			modelMatrix = rotate(modelMatrix, plane_rotation, rotation_axis);
			modelMatrix = translate(modelMatrix, vec3(-0.3, 0.15, 0));
			modelMatrix = scale(modelMatrix, vec3(0.4, 0.1, 1.6));
			RenderMesh(meshes["box"], shaders["Color"], modelMatrix, vec3(1, 0, 0));
		}

		{
			mat4 modelMatrix = mat4(1);
			modelMatrix = translate(modelMatrix, vec3(0, plane_position, 0));
			modelMatrix = rotate(modelMatrix, plane_rotation, rotation_axis);
			modelMatrix = translate(modelMatrix, vec3(-0.7, 0.3, 0));
			modelMatrix = scale(modelMatrix, vec3(0.2, 0.3, 0.1));
			RenderMesh(meshes["box"], shaders["Color"], modelMatrix, vec3(1, 0, 0));
		}

		{
			mat4 modelMatrix = mat4(1);
			modelMatrix = translate(modelMatrix, vec3(0, plane_position, 0));
			modelMatrix = rotate(modelMatrix, plane_rotation, rotation_axis);
			modelMatrix = translate(modelMatrix, vec3(0.05, 0, 0));
			modelMatrix = scale(modelMatrix, vec3(0.1, 0.5, 0.5));
			RenderMesh(meshes["box"], shaders["Color"], modelMatrix, vec3(0, 0, 0));
		}

		{
			mat4 modelMatrix = mat4(1);
			modelMatrix = translate(modelMatrix, vec3(0, plane_position, 0));
			modelMatrix = rotate(modelMatrix, plane_rotation, rotation_axis);
			modelMatrix = translate(modelMatrix, vec3(0.15, 0, 0));
			modelMatrix = scale(modelMatrix, vec3(0.1, 0.1, 0.1));
			RenderMesh(meshes["box"], shaders["Color"], modelMatrix, vec3(1, 0.8, 0));
		}

		{
			static float rotation = 0;
			rotation += deltaTimeSeconds * 5;
			mat4 modelMatrix = mat4(1);
			modelMatrix = translate(modelMatrix, vec3(0, plane_position, 0));
			modelMatrix = rotate(modelMatrix, plane_rotation, rotation_axis);
			modelMatrix = translate(modelMatrix, vec3(0.2, 0, 0));
			modelMatrix = rotate(modelMatrix, rotation, vec3(1, 0, 0));
			modelMatrix = scale(modelMatrix, vec3(0.1, 1, 0.1));
			RenderMesh(meshes["box"], shaders["Color"], modelMatrix, vec3(0, 0, 0));
		}
	}

	// Interfata
	{
		// Vieti
		{
			for (int i = 0; i < lives; i++)
			{
				mat4 modelMatrix = mat4(1);
				modelMatrix = translate(modelMatrix, vec3(-1.5 + 0.25 * i, 2.75, 2));
				modelMatrix = scale(modelMatrix, vec3(0.2, 0.2, 0.2));
				RenderMesh(meshes["sphere"], shaders["Color"], modelMatrix, vec3(1, 0, 0));
			}
		}

		// Combustibil
		{
			{
				mat4 modelMatrix = mat4(1);
				modelMatrix = translate(modelMatrix, vec3(2.5, 2.5, 2));
				modelMatrix = scale(modelMatrix, vec3(1.2, 0.25, 0.1));
				modelMatrix = translate(modelMatrix, vec3(0.5, 0, 0));
				RenderMesh(meshes["box"], shaders["Color"], modelMatrix, vec3(0, 0, 0));
			}

			{
				mat4 modelMatrix = mat4(1);
				modelMatrix = translate(modelMatrix, vec3(2.5, 2.5, 2.2));
				modelMatrix = scale(modelMatrix, vec3(fuel, 0.2, 0.1));
				modelMatrix = translate(modelMatrix, vec3(0.5, 0, 0));
				RenderMesh(meshes["box"], shaders["Color"], modelMatrix, vec3(1, fuel * 2, fuel * 2));
			}
		}
	}

	// Mare
	{
		elapsed_time += deltaTimeSeconds;

		{
			mat4 modelMatrix = mat4(1);
			modelMatrix = scale(modelMatrix, vec3(5, 0.6, 3));
			modelMatrix = rotate(modelMatrix, elapsed_time, vec3(0, 0, 1));
			modelMatrix = rotate(modelMatrix, (float)M_PI_2, vec3(1, 0, 0));
			RenderMesh(meshes["sea"], shaders["Wave"], modelMatrix, vec3(0, 0.6, 0.8));
		}
	}
}

void Avioncumotor::FrameEnd()
{
}

void Avioncumotor::RenderMesh(Mesh * mesh, Shader * shader, const mat4 & modelMatrix, vec3 color)
{
	if (!mesh || !shader || !shader->program)
		return;

	// render an object using the specified shader and the specified position
	shader->Use();
	glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE, value_ptr(camera->GetViewMatrix()));
	glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE, value_ptr(projectionMatrix));
	glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, value_ptr(modelMatrix));
	glUniform3fv(shader->GetUniformLocation("color"), 1, value_ptr(color));

	if(!strcmp(shader->GetName(), "Wave"))
		glUniform1fv(shader->GetUniformLocation("time"), 1, &elapsed_time);

	mesh->Render();
}

void Avioncumotor::OnInputUpdate(float deltaTime, int mods)
{
}

void Avioncumotor::OnKeyPress(int key, int mods)
{
	if (key == GLFW_KEY_ESCAPE || game_over)
		exit(0);
}

void Avioncumotor::OnKeyRelease(int key, int mods)
{
}

void Avioncumotor::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	ivec2 resolution = window->GetResolution();

	pos_mouseY = (1 - (float)mouseY / resolution.y) * 2;
}

void Avioncumotor::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
}

void Avioncumotor::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
}

void Avioncumotor::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Avioncumotor::OnWindowResize(int width, int height)
{
}
