#pragma once

#include <include/glm.h>

using namespace glm;

class Collider
{
public:
	Collider(int type, vec3 position, float radius, float elapsed);
	bool CheckColision(Collider);

	float elapsed_time;
	vec3 position;
	float radius;
	int type;
};