Avion:

La fiecare update al scenei se calculeaza noua pozitie in functie de pozitia
mouseului. Folosind o intermpolare liniara pentru tranzitia mai devine mai
fluida. In functie de noua pozitie si cea precedenta, e calculata rotatia
avionului. In caz ca jocul s-a incheiat, avionul va cadea si se va roti fara a
mai tine cont de pozitia mouseului.

Interfata:

Pe masura ce avionul ramane fara combustibil culoarea dreptunghiului se va
schimba.

Marea:

E reprezentata de un cilindru, si foloseste shader-ul Wave pentru a simula
valurile. Shaderul primeste timpul si in functie de pozitia punctului si de
timp calculeaza noi pozitii pentru al ridica sau cobora. In functie de
inaltime daca e mai inalt valul e mai deschis la culoare, altfel culoarea se
inchide.

Obstacole & combustibil:

Sunt generate aleator dupa un anumit timeout care e la randul lui aleator.
Pentru reprezentare, au fost folosite obiecte de tip collider care inglobeaza
datele necesare pentru realizarea calculelor de coliziune. Aceste obiecte sunt
stocate intr-un vector si in momentul in care ies din zona de joc, sunt
eliminate.

Coliziuni:

Sunt realizate folosind coliziuni sferice, fiecarui obiect fiindu-i atribuit
un spatiu de coliziune care sa inglobeze cat mai mult din obiect. Cand e
detectata o coliziune, obiectul e distrus, iar in functie de tipul lui, sunt
actualizate vietile sau combustibilul.