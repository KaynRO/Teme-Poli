module Parser
where

import Util
import ClassState
import Data.Maybe
import Data.Char
import Data.List
import Data.Either
import InferenceDataType
import Data.Map(Map)
import Data.Maybe

-- Definire Program

type Program = [(String, String, ClassState)]
type Instruction = [String]

-- Definire functii pentru 3-tuplu
fst3 :: (String, String, ClassState) -> String
fst3 (x, _, _) = x
snd3 :: (String, String, ClassState) -> String
snd3 (_, x, _) = x
thd3 :: (String, String, ClassState) -> ClassState
thd3 (_, _, x) = x

-- Implementare functii de cautare pentru vectorul de 3-tuple, si manageriat continutul acestuia
initEmptyProgram :: Program
initEmptyProgram = [("Global", "Global", initEmptyClass)]

getVars :: Program -> [[String]]
getVars program = concat $map (\x -> getValues x Var) (map (thd3) (filter (\x -> fst3 x == "Global") program))

getClasses :: Program -> [String]
getClasses program = sort $map (fst3) program

getParentClass :: String -> Program -> String
getParentClass name program  = snd3 $head (filter (\x -> fst3 x == name) program)

getFuncsForClass :: String -> Program -> [[String]]
getFuncsForClass name program = concat $map (\x -> getValues x Func) (map (thd3) (filter (\x -> fst3 x == name) program))

classExists :: String -> Program -> Bool
classExists name program = if length (filter (\x -> fst3 x == name) program) > 0 then True else False

classParent :: Instruction -> String
classParent instr = if length instr == 4 then head $drop 3 instr else "Global"

-- Updatam intrarea din vector
tupleReplace :: Program -> (String, String, ClassState) -> String -> Program
tupleReplace program tuple name = (filter (\x -> fst3 x /= name) program) ++ [tuple]

-- Verifica daca o functie este definita corespunzator
isFuncValid :: Instruction -> Program -> Bool
isFuncValid instr program = if length (filter (\x -> classExists x program == False) ((take 2 instr) ++ (drop 3 instr))) > 0 then False else True

-- Verificam daca exista o variabila anume
varExists :: String -> Program -> Bool
varExists name program = if length (filter (\x -> head x == name) (getVars program)) > 0 then True else False

-- Obtinem tipul unei varaibile
getVarType :: String -> Program -> String
getVarType name program = head $tail $concat $filter (\x -> head x == name) $getVars program

-- Obtinem toate functiile cu un nume specific
getFunc :: String -> Program -> [[String]]
getFunc name program = concat $map (\x -> (filter(\y -> head y == name) x)) allFunc
                       where allFunc = map (\x -> getValues x (Func)) $map (\x -> thd3 x) program

-- modelare Fcall
fCall :: [String] -> Program -> Maybe String
fCall line program = if length answer > 0 then Just (head $head answer) else Nothing

                    where funcName = head line
                          param = filter (\x -> x /= "Va") $tail line
                          paramCandidates = map (\x -> tail x) $getFunc funcName program
                          answer = filter (\x -> tail x == param) paramCandidates


-- Pentru parsare eliminam toate caracterele ce nu sunt litere si stocam ca instructiuni
parse :: String -> [Instruction]
parse text = filter (\x -> length x /= 0) $map (words) $map (map (\x -> if isLetter x || isDigit x then x else ' ')) $lines text


interpret :: Instruction -> Program -> Program
interpret instr program      
        | head instr == "class" = if (classExists (head instr) program) 
                                        then program 
                                        else if classExists (classParent instr) program 
                                            then program ++ [(head $tail instr, classParent instr, initEmptyClass)] 
                                            else program ++ [(head $tail instr, "Global", initEmptyClass)]
        | head instr == "newvar" = if classExists (head $ drop 2 instr) program then program1 else program
        | otherwise = if isFuncValid instr program then program2 else program
        where program1 = tupleReplace program ("Global", "Global", insertIntoClass (thd3 $head $filter (\x -> fst3 x == "Global") program) (Var) (tail instr)) "Global"
              program2 = tupleReplace program ((head $tail instr), getParentClass (head $tail instr) program, insertIntoClass (thd3 $head $filter (\x -> fst3 x == head (tail instr)) program) (Func) ([head $drop 2 instr] ++ [head instr] ++ (drop 3 instr))) (head $tail instr)

infer :: Expr -> Program -> Maybe String
infer expr program =  if head line == "Va" then if varExists name program then Just (getVarType name program) else Nothing else fCall (drop 2 line) program
                      where line = concat $parse (show expr)
                            name = head $tail line


