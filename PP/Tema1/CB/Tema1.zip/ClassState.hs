module ClassState where

import Data.Map(Map)
import Data.Maybe
import qualified Data.Map as Map

-- Utilizat pentru a obține informații despre Variabile sau Funcții
data InstrType = Var | Func  deriving (Show, Eq)

-- In cazul de fata, putem vedea containerul ca o mapa in care tinem detalii despre diferite simboluri
type ClassState = Map String [[String]]

initEmptyClass :: ClassState
initEmptyClass = Map.empty

-- Cheia este Var/Func, descrierea acestuia alcatuiesc spatiul valorilor
insertIntoClass :: ClassState -> InstrType -> [String] -> ClassState
insertIntoClass map instr value = Map.insertWith (++) (show instr) [value] map

getValues :: ClassState -> InstrType -> [[String]]
getValues map instr = Map.findWithDefault [] (show instr) map