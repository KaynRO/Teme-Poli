/*
 * Loader Implementation
 *
 * 2018, Operating Systems
 */

#include <stdio.h>
#include <assert.h>
#include <limits.h>
#include <windows.h>

#define DLL_EXPORTS
#include "loader.h"
#include "exec_parser.h"
#include "utils.h"

#define UNKNOWN_PERMISSION -1
#define SEG_NOT_FOUND -1
#define DIM_PAGE 65536
#define MAPPED 1
#define UNMAPPED 0

HANDLE handle;
static so_exec_t *exec;
static LPVOID access_violation_handler;

static LONG CALLBACK access_violation(PEXCEPTION_POINTERS ExceptionInfo)
{
	int index_seg;
	int index_page;
	int no_pages, perms;
	int res;
	char zero_page;
	LPBYTE addr;
	LPBYTE lpMapAddress;
	LPBYTE start;
	LPBYTE finish;
	LPBYTE fd_address;
	DWORD allocationType;
	DWORD protect;
	DWORD old, rc;

	//determinam adresa unde s-a produs seg_fault
	addr = (LPBYTE)ExceptionInfo->ExceptionRecord->ExceptionInformation[1];
	//determinam indexul segmentului din care face parte adresa
	for (index_seg = 0; index_seg < exec->segments_no; index_seg++) {
		start = (LPBYTE)exec->segments[index_seg].vaddr;
		finish = (LPBYTE)exec->segments[index_seg].vaddr
			+ exec->segments[index_seg].mem_size;
		if (start <= addr && addr <= finish)
			break;
	}
	if (index_seg >= exec->segments_no)
		index_seg = SEG_NOT_FOUND;
	//daca nu am gasit niciun index de segment,apelam handlerul default
	if (index_seg == SEG_NOT_FOUND)
		return EXCEPTION_CONTINUE_SEARCH;
	//calculam numarul de pagini complete(e posibil sa fie inca
	//una la sfarsit din care o sa mapam doar o parte din handle
	//in functie de restul lui file_size la DIM_PAGE;
	no_pages = exec->segments[index_seg].file_size / DIM_PAGE;

	//cautam indexul paginii din segment
	index_page = (int)((addr - (int)exec->segments[index_seg].vaddr));
	index_page = index_page/DIM_PAGE;

	//daca a fost mapat deja inseamna apelam handlerul default intrucat
	//segfault se datoreaza lipsei unor permisiuni pe acea zona
	if (*((char *)exec->segments[index_seg].data + index_page) == MAPPED)
		return EXCEPTION_CONTINUE_SEARCH;

	//daca file_size nu se imparte exact la DIM_PAGE
	//inseamna ca o sa mai avem o pagina cu o parte de info
	//si restul 0-uri.
	zero_page = (exec->segments[index_seg].file_size % DIM_PAGE == 0)?0:1;

	allocationType = MEM_COMMIT | MEM_RESERVE;
	old = PAGE_READWRITE;
	protect = PAGE_READWRITE;
	addr = (void *)(exec->segments[index_seg].vaddr
			+ index_page * DIM_PAGE);
	lpMapAddress = VirtualAlloc(addr, DIM_PAGE,
		allocationType, protect);
	fd_address = (LPBYTE)(exec->segments[index_seg].offset
			+ index_page * DIM_PAGE);
	//daca mapam o pagina intreaga din handle
	if (index_page < no_pages) {
		SetFilePointer(handle, (long)fd_address, NULL, FILE_BEGIN);
		ReadFile(handle, lpMapAddress, DIM_PAGE, &res, NULL);
	//daca mapam doar o parte de pagina din handle + zerouri in rest
	} else if (index_page == no_pages && zero_page == 1) {
		int length;

		length = exec->segments[index_seg].file_size % DIM_PAGE;
		SetFilePointer(handle, (long)fd_address, NULL, FILE_BEGIN);
		ReadFile(handle, lpMapAddress, length, &res, NULL);
		//restul sunt deja initializate la 0 de catre apelul
		// VirtualAlloc
	}

	//Nu mai tratam cazul else din LINUX pentru ca VirtualAlloc
	//initializeaza deja la 0 pagina.

	//Setam permisiunile
	if (exec->segments[index_seg].perm == 0)
		perms = PAGE_NOACCESS;

	else if (exec->segments[index_seg].perm == 1)
		perms = PAGE_READONLY;

	else if (exec->segments[index_seg].perm == 2)
		perms = UNKNOWN_PERMISSION;

	else if (exec->segments[index_seg].perm == 3)
		perms = PAGE_READWRITE;

	else if (exec->segments[index_seg].perm == 4)
		perms = PAGE_EXECUTE;

	else if (exec->segments[index_seg].perm == 5)
		perms = PAGE_EXECUTE_READ;

	else if (exec->segments[index_seg].perm == 6)
		perms = UNKNOWN_PERMISSION;

	else if (exec->segments[index_seg].perm == 7)
		perms = PAGE_EXECUTE_READWRITE;

	rc = VirtualProtect(lpMapAddress, DIM_PAGE,
				perms, &old);

	*(char *)((int)exec->segments[index_seg].data + index_page) = MAPPED;

	return EXCEPTION_CONTINUE_EXECUTION;
}

int so_init_loader(void)
{
	access_violation_handler = AddVectoredExceptionHandler(1,
			access_violation);
	DIE(access_violation_handler == NULL, "AddVctoredExceptionHandler");
	return -1;
}


void initialize(void)
{
	int i, j;

	for (i = 0; i < exec->segments_no; i++) {
		int no_pages;

		no_pages = exec->segments[i].mem_size / DIM_PAGE;
		if (exec->segments[i].mem_size % DIM_PAGE != 0)
			no_pages++;

		exec->segments[i].data =
			(char *)malloc(no_pages * sizeof(char));
		//initializeaza la UNMAPPED fiecare element
		for (j = 0; j < no_pages; j++)
			*(char *)((int)exec->segments[i].data + j) = UNMAPPED;
	}

}

int so_execute(char *path, char *argv[])
{
	exec = so_parse_exec(path);
	//daca avem eroare la exec
	if (!exec)
		return -1;

	handle = CreateFile(path, GENERIC_READ, 0, NULL,
		OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	//daca avem un handle invalid
	if (handle == INVALID_HANDLE_VALUE)
		return -1;
	//initializeaza campul data pentru fiecare segment
	initialize();

	so_start_exec(exec, argv);

	return -1;
}
